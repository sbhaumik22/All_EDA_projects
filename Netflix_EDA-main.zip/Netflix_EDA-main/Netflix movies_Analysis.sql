USE Netfilx_db;
CREATE DATABASE Netfilx_db;

SELECT * FROM titles;

-- top 10 movies according to IMDB score
SELECT title, imdb_score FROM titles
WHERE type = "MOVIE"
ORDER BY imdb_score DESC
LIMIT 10;

-- top 10 shows according to IMDB score
SELECT title, imdb_score FROM titles
WHERE type = "SHOW"
ORDER BY imdb_score DESC
LIMIT 10;

-- the bottom 10 movies according to IMDB score
SELECT title, imdb_score FROM titles
WHERE type = "MOVIE"
ORDER BY imdb_score ASC
LIMIT 10;

-- the bottom 10 shows according to IMDB score
SELECT title, imdb_score FROM titles
WHERE type = "SHOW"
ORDER BY imdb_score ASC
LIMIT 10;

-- average IMDB and TMDB scores for shows and movies
SELECT type, ROUND(AVG(imdb_score), 2) AS avg_imdb_score, ROUND(AVG(tmdb_score), 2) AS avg_tmdb_score
FROM titles
GROUP BY type;

-- Count of movies and shows in each decade
SELECT CONCAT(FLOOR(release_year / 10) * 10, 's') AS decade,
	COUNT(*) AS movies_shows_count
FROM titles
GROUP BY CONCAT(FLOOR(release_year / 10) * 10, 's')
ORDER BY decade;

-- average IMDB and TMDB scores for each production country
SELECT production_countries, ROUND(AVG(imdb_Score), 2) AS avg_imdb_score, ROUND(AVG(tmdb_Score), 2) AS avg_tmdb_score 
FROM titles
GROUP BY production_countries;

-- average IMDB and TMDB scores for each age certification for shows and movies
SELECT age_certification, ROUND(AVG(imdb_Score), 2) AS avg_imdb_score, ROUND(AVG(tmdb_Score), 2) AS avg_tmdb_score
FROM titles
GROUP BY age_certification
ORDER BY age_certification;

-- 5 most common age certifications for movies?
SELECT age_certification, COUNT(*) AS certification_count
FROM titles
WHERE type = "MOVIE"
GROUP BY age_certification 
ORDER BY certification_count DESC
LIMIT 5;


-- top 20 actors that appeared the most in movies/shows
SELECT name, COUNT(*) AS number_of_apperarences FROM credits
WHERE role = "ACTOR"
GROUP BY name
ORDER BY number_of_apperarences DESC
LIMIT 20;

-- top 20 directors that directed the most movies/shows
SELECT name, COUNT(*) AS number_of_apperarences FROM credits
WHERE role = "DIRECTOR"
GROUP BY name
ORDER BY number_of_apperarences DESC
LIMIT 20;

-- Calculating the average runtime of movies and TV shows separately
SELECT type, AVG(runtime) FROM titles
GROUP BY type;

-- Finding the titles and  directors of movies released on or after 2010
SELECT DISTINCT t.title, c.name AS director, 
release_year
FROM titles AS t
JOIN credits AS c 
ON t.id = c.id
WHERE t.type = 'Movie' 
AND t.release_year >= 2010 
AND c.role = 'director'
ORDER BY release_year DESC;

-- shows on Netflix have the most seasons
SELECT * FROM titles
WHERE type = "SHOW"
ORDER BY seasons DESC
LIMIT 10;

-- genres had the most movies
SELECT genres, COUNT(*) AS count_of_movies FROM titles
WHERE type = "MOVIE"
GROUP BY genres
ORDER BY count_of_movies DESC;

-- What were the total number of titles for each year? 
SELECT release_year, COUNT(*) AS count_of_titles FROM titles
GROUP BY release_year
ORDER BY release_year DESC;

-- top 3 most common genres
SELECT genres, COUNT(*) AS count_of_titles FROM titles
GROUP BY genres
ORDER BY count_of_titles DESC
LIMIT 3;
